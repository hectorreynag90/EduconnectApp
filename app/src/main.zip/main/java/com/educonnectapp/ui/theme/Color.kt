package com.educonnectapp.ui.theme

import androidx.compose.ui.graphics.Color

//Colores primarios
val EduconnectBlue = Color(0xFF02529E)         // Azul primario
val EduconnectBlueMedium = Color(0xFF1976D2)  // Azul secundario
val EduconnectBlueLight = Color(0xFF42A5F5)   // Azul degradado

//Colores de acento
val AccentOrange = Color(0xFFFF4625)       // acento orange fuerte
val AccentOrangeLight = Color(0xFFFFB476)  // acento orange degradado suave

val AsistentTardanza = Color(0xFFFCEADC)

//Estados
val StatusGreen = Color(0xFF04834C)       // Presente
val StatusErrorRed = Color(0xFFC22105)    // Ausente
val Warning = Color(0xFFFF8F00)           // Advertencia

//Superficies y fondos
val Background = Color(0xFF02529E)                  // Fondo principal
val BackgroundWhite = Color(0xFFFFFFFF)             // Fondo de tarjetas y formularios
val BackgroundLight = Color(0xFFF0F0F0)             // Fondo suave de íconos acento
val BackgroundRedLight = Color(0XFFFFEAE6)
val BackgroundBlueLight = Color(0xFFEBF3FF)
val BackgroundStatusGreenLight = Color(0xFFEFFFF6)  // Fondo estado asistencia detalle green
val BackgroundStatusRedLight = Color(0xFFFFE8E8)

val BackgroundStatusOrangeLight = Color(0xFFFFF5ED)// Fondo estado asistencia detalle red

//Textos
val TextPrimary = Color(0xFF212121)        // Texto principal
val TextSecondary = Color(0xFF757575)      // Texto secundario y placeholders
val TextWhite = Color(0xFFFFFFFF)          // Texto sobre fondos oscuros
val TextBlue = Color(0xFF02529E)
val TextRed = Color(0xFFC22105)
// Texto de enlaces y etiquetas

val TextOrange = Color(0xFFFF4625)         //Texto naranja enlace

//Bordes y divisores
val BorderLight = Color(0xFFDDDDDD)
val BorderRed= Color(0xFFC22105)// Borde de inputs y cards
val BorderOrange= Color(0xFFFF4625)
val BorderMedium = Color(0xFFAAAAAA)       // Borde medio
val DividerColor = Color(0xFFEEEEEE)       // Líneas divisoras
val BorderBlue = Color(0xFF42A5F5)
val BorderGreen = Color(0xFF04834C)  // Borde verde

//Navegación inferior
val NavBarBackground = Color(0xFF212121)   // Fondo navbar
val NavIconActive = Color(0xFF1565C0)      // Ícono activo
val NavIconInactive = Color(0xFF757575)    // Ícono inactivo

//Colores tarjeta
val Bluetarjet= Color(0xFF1565C0)         // Color Fondo azul tarjeta
val GreenTarjet = Color(0xFF00B050)       // Color Fondo verde tarjeta
val OrangeTarjet = Color(0xFFFF8F00)      // Color Fondo naranja tarjeta

//Asistencia
val AsistenciaPresente = Color(0xFFE8F5E9) // Fondo botón Presente activo
val AsistenciaAusente = Color(0xFFFFEBEE)  // Fondo botón Ausente activo
val AsistenciaPendiente = Color(0xFFFFF3F0)// Fondo alumno sin marcar

//Recuperar contraseña (encabezados y botones en azul oscuro sólido, sin degradado)
val AzulOscuro = Color(0xFF0D47A1)         // Encabezado y botones principales
val FondoCampoAzul = Color(0xFFE3EEFD)     // Fondo de campos y casillas del código
val VerdeOk = Color(0xFF1B9E4B)            // Check, contraseña válida, seguridad "Fuerte"
val VerdeTexto = Color(0xFF1B7F3B)         // Texto del aviso "Código enviado"
val FondoVerde = Color(0xFFEAF9EF)         // Fondo del aviso verde y de campos válidos
val RojoError = Color(0xFFD32F2F)          // Código incorrecto, contador, alertas
val FondoRojo = Color(0xFFFFF1F0)          // Fondo de casillas y avisos en rojo
val NaranjaMedia = Color(0xFFF59E0B)       // Seguridad "Media" y avisos

// =====================================================================
// PALETA 2026 (rediseño "Prototipo B")
// Las pantallas se migran una por una a estos colores. Los colores de
// arriba se eliminarán cuando ninguna pantalla los use.
// =====================================================================

// Turquesa: color principal (cabeceras, "Asistió", "Entregado", ítem activo)
val EduTeal = Color(0xFF16A085)
val EduTealOscuro = Color(0xFF0E7C66)          // Texto e íconos turquesa sobre blanco
val EduTealClaro = Color(0xFFDDF3EE)           // Fondo de chips y avisos turquesa
val EduTealTextoCabecera = Color(0xFFE4F6F1)   // Subtítulos sobre la cabecera turquesa
val EduTealCirculo1 = Color(0xFF1FB596)        // Círculos decorativos de la bienvenida
val EduTealCirculo2 = Color(0xFF13937A)

// Amarillo: botón de acción principal, "Tardanza", "Pendiente"
val EduAmarillo = Color(0xFFFFC107)
val EduAmarilloOscuro = Color(0xFF8A5A00)      // Texto amarillo legible sobre fondo claro
val EduAmarilloClaro = Color(0xFFFFF4D1)

// Coral (granate #910428): "Faltó", "No entregado", errores y acciones de eliminar
val EduCoral = Color(0xFF910428)
val EduCoralOscuro = Color(0xFF6B031D)         // Texto legible sobre fondo claro
val EduCoralClaro = Color(0xFFF2E1E5)          // Fondo suave (chips, campos con error)

// Azul oscuro: evaluaciones y pantallas de seguridad
val EduAzulOscuro = Color(0xFF2C3E50)
val EduAzulOscuroClaro = Color(0xFFE3E8EE)

// Textos, fondos y bordes
val EduTexto = Color(0xFF22303F)               // Texto principal
val EduTextoSecundario = Color(0xFF5F6B7A)     // Texto secundario y placeholders
val EduEtiqueta = Color(0xFF3D4A5A)            // Etiquetas de los campos
val EduFondo = Color(0xFFECEFF2)               // Fondo general de las pantallas
val EduCampo = Color(0xFFF4F6F8)               // Fondo de los campos de texto
val EduBorde = Color(0xFFDCE1E6)               // Borde de campos y divisores
